#include Arduino.h
#include H_Bridge.h

//set the paramiters to where pins are located.
//set all 3 pins to output
H_Bridge::H_Bridge(int IN1, int IN2, int EN){

}

//set both in pins low
H_Bridge::stop(){

}

//should spin the motor if derection is -1 (H_Bridge.BACK) or 1 (H_Bridge.FORWARd
//when a derection is selected the opisite derection should be turned off first
//if 0(H_Bridge.STOP)is selected for derection call function H_Bridge.stop()
// setting the in1 high should spin motor one way, in2 high schould spin the motor the other way
//only one in pin can be high at a time the other must be pulled low first
H_Bridge::start(int derection, int speed){

}
